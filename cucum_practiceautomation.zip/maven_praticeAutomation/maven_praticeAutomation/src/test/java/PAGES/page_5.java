package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilites.libraries;

public class page_5 
{
	WebDriver dr;
	WebElement we;
	libraries l;
	
	public page_5(WebDriver dr)
	{
		this.dr=dr;
		l=new libraries(dr);
	}
	
	By f=By.xpath("//input[@placeholder='First Name']");
	By L=By.xpath("//input[@placeholder='Last Name']");
	By a=By.xpath("//textarea[@ng-model='Adress']");
	By e=By.xpath("//input[@ng-model='EmailAdress']");
	By p=By.xpath("//input[@ng-model='Phone']");
	By g=By.xpath("//input[@value='FeMale']");
	By c=By.xpath("//input[@id='checkbox1']");
	By b=By.xpath("//div[@class='ui-autocomplete-multiselect ui-state-default ui-widget']");
	By d=By.xpath("//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all']//li[8]//a");
	By h=By.xpath("//select[@id='countries']");
	By i=By.xpath("//select[@id='Skills']");
	By j=By.xpath("//span[@class='select2-selection__arrow']");
	By k=By.xpath("//*[@id=\"select2-country-results\"]/li[6]");
	By m=By.xpath("//select[@id='yearbox']//option[10]");
	By n=By.xpath("//select[@placeholder='Month']//option[4]");
	By o=By.xpath("//select[@placeholder='Day']//option[4]");
	By q=By.xpath("//input[@id='firstpassword']");
	By r=By.xpath("//input[@id='secondpassword']");
	By button=By.xpath("//button[@id='submitbtn']");
	 By demo=By.xpath("//ul[@id='main-nav']//li[5]//a");
	 public void Democlick()
	 {
		 we=l.clickable(demo,50);
		 we.click();
	 }
	
	public void f_n(String n1)
	{
		we=l.waitelement(f, 20);
		we.sendKeys(n1);
	}
	public void l_n(String n2)
	{
		we=l.waitelement(L, 20);
		we.sendKeys(n2);
	}
	public void add(String a1)
	{
		we=l.waitelement(a, 20);
		we.sendKeys(a1);
		
	}
	public void eid(String e1)
	{
		we=l.waitelement(e, 20);
		we.sendKeys(e1);
	}
	public void phone(String p1)
	{
		we=l.waitelement(p, 20);
		we.sendKeys(p1);
	}
	public void cb1()
	{
		we=l.clickable(g, 20);
		we.click();
	}
	public void cb2()
	{
		we=l.clickable(c,20);
		we.click();
	}
	public void b1()
	{
		we=l.clickable(b, 20);
		we.click();
	}
	public void d1()
	{
		we=l.clickable(d,100);
		we.click();
	}
	public void i1()
	{
		WebElement we1=dr.findElement(By.xpath("//select[@id='Skills']"));
		Select s1=new Select(we1);
		s1.selectByVisibleText("C");
	}
	public void h1()
	{
		WebElement we2=dr.findElement(By.xpath("//select[@id='countries']"));
		Select s2=new Select(we2);
		s2.selectByVisibleText("India");
	}
	public void j1()
	{
		we=l.clickable(j,20);
		we.click();
	}
	public void k1()
	{
		we=l.clickable(k, 20);
		we.click();
	}
	public void m1()
	{
		we=l.clickable(L, 20);
		we.click();
	}
	public void z()
	{
		we=l.clickable(m, 20);
		we.click();
	}
	public void n2()
	{
		we=l.clickable(n, 20);
		we.click();						
	}
	public void o1()
	{
		we=l.clickable(o, 20);
		we.click();
	}
	public void q1(String q2)
	{
		we=l.waitelement(q, 20);
		we.sendKeys(q2);
	}
	public void r1(String r2)
	{
		we=l.waitelement(r, 20);
		we.sendKeys(r2);
	}
	public void clk_btn()
	{
		we=l.clickable(button, 50);
		we.click();
	}
	public void demosite(String f2,String l2,String a2,String e2,String p2,String q2,String r2)
	{
		this.Democlick();
		this.f_n(f2);
		this.l_n(l2);
		this.add(a2);
		this.eid(e2);
		this.phone(p2);
		this.cb1();
		this.cb2();
		this.b1();
		this.d1();
		this.i1();
		this.h1();
		this.j1();
		this.k1();
		this.z();
		this.m1();
		this.n2();
		this.o1();
		this.q1(q2);
		this.r1(r2);
		this.clk_btn();
		l.getScreenshot();
	}
	

}
