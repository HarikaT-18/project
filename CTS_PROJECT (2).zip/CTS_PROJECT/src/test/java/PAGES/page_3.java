package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilites.libraries;

public class page_3 
{
	WebDriver dr;
	WebElement we;
	libraries l;
	
	public page_3(WebDriver dr)
	{
		this.dr=dr;
	}
	
	By l_out=By.xpath("//nav[@class='woocommerce-MyAccount-navigation']//ul//li[6]//a");
    // By s=By.xpath("//ul[@id='main-nav']//li[1]//a");
	
	public void logout()
	{
		we=l.clickable(l_out, 20);
		we.click();
	}
	
public void clk_logout()
{
	this.logout();
}
	
}
