package Utilites;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class libraries 
{
	static WebDriver dr;
	
	public WebElement waitelement(By Locator,int timeout)
	{
		WebElement e=null;
		try
		{
		WebDriverWait wait= new WebDriverWait(dr,timeout);
		 e=wait.until(ExpectedConditions.visibilityOfElementLocated(Locator));
		System.out.println("element located");

		}
		catch(Exception e1)
		{
			
		  System.out.println("element not found"+e1);	
		}
	return e;	
	}
	public WebElement clickable(By Locator, int timeout) 
	{
		WebElement e=null;
		try 
		{
			WebDriverWait wait = new WebDriverWait(dr,timeout);
			e= wait.until(ExpectedConditions.elementToBeClickable(Locator));
			System.out.println("element located");
			return e;
		}
		catch(Exception e1)
		{

			  System.out.println("element not found"+e1);	
		}
		return null;
	}

}
